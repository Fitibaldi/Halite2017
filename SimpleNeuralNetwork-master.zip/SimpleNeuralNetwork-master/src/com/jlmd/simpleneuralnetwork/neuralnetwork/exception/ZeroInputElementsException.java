package com.jlmd.simpleneuralnetwork.neuralnetwork.exception;

/**
 * Exception for when there are not input elements
 * @author jlmd
 */
public class ZeroInputElementsException extends Exception {
}
