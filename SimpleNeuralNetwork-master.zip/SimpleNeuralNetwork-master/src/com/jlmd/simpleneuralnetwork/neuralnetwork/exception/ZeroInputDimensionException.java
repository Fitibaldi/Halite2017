package com.jlmd.simpleneuralnetwork.neuralnetwork.exception;

/**
 * Exception for when input dimension is zero
 * @author jlmd
 */
public class ZeroInputDimensionException extends Exception {
}
